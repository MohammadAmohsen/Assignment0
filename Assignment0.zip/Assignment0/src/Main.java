package src;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Square sq = new Square("Square");
        Circle c = new Circle("Circle");
        Triangle t = new Triangle("Triangle");
        EquTriangle eq = new EquTriangle("Equilateraltriangle");
        

        System.out.println("Enter the length of the square: ");
        double length = sc.nextDouble();
        System.out.println("Enter the height of the square: ");
        double height = sc.nextDouble();
        sq.setDimensions(length, height);

        System.out.println("Enter the radius of the circle: ");
        double radius = sc.nextDouble();
        c.setDimensions(radius);

        //prompt user - Triangle
        System.out.println("Enter the length of the first side of the triangle: ");
        double side1 = sc.nextDouble();
        System.out.println("Enter the length of the second side of the triangle:  ");
        double side2 = sc.nextDouble();
        System.out.println("Enter the length of the third side of the triangle: ");
        double side3 = sc.nextDouble();
        t.setDimensions(side1, side2, side3);

        //prompt user - EQTriangle
        System.out.println("Enter length of  Equilateral Triangle: ");
        double EquSide = sc.nextDouble();
        eq.setDimensions(EquSide);

        
        System.out.println(sq.getName() + "'s' area = " + sq.getArea());
        sq.printDimensions();

        System.out.println(c.getName() + "'s area = " + c.getArea());
        c.printDimensions();

        System.out.println(t.getName() + "'s' area =  " + t.getArea());
        t.printDimensions();

        System.out.println(eq.getName() + "'s area =" + eq.getArea());
        eq.printDimensions();

        sc.close();
    }

}
