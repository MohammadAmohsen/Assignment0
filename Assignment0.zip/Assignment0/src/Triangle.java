
package src;

public class Triangle extends Shape {
    private double side1;
    private double side2;
    private double side3;
    private double perimeter; 

    public Triangle(){}

    public Triangle(String Triangle){
        super(Triangle);
    }

    public void setDimensions(double side1, double side2, double side3){
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
        this.perimeter = side1 + side2 + side3;
    }

    @Override
    public void printDimensions(){
        System.out.println("The first side is " + side1);
        System.out.println("The second side is " + side2);
        System.out.println("The third side is " + side3);
    }

    @Override
    public double getArea(){
        double value = perimeter*(.5);
        return Math.sqrt(value*(value-side1)*(value-side2)*(value-side3)); 
    }
}
