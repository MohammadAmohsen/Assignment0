
package src;
public class EquTriangle extends Triangle {
        private double sides;
        private double perimeter; 
    
        public EquTriangle(){}
    
        public EquTriangle(String EquTriangle){
            super(EquTriangle);
        }
    
        public void setDimensions(double sides){
            this.sides = sides;
            this.perimeter = sides*3;
        }
    
        @Override
        public void printDimensions(){
            System.out.println("The sides are " + sides);
        }
    
        @Override
        public double getArea(){
            double value = perimeter*(.5);
            return Math.sqrt(value*(value-sides)*(value-sides)*(value-sides)); 
        }
    }
    